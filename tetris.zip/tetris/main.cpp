#include "tetrisGame.h"

void main()
{
	run();
	//Board board();
	//board.drawBoardBorders();
	//cout << endl;
}