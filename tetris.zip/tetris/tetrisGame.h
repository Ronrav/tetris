#pragma once
#include "board.h"

void run();
char handleStartMenu();
char handlePauseMenu();
void printInstructions();